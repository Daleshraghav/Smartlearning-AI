from flask import Flask, render_template, send_from_directory
import json
import os

app = Flask(__name__)

def load_formula_data():
    data_path = os.path.join(app.root_path, "formula_data.json")
    with open(data_path, encoding="utf-8") as f:
        return json.dumps(json.load(f, encoding="utf-8"), ensure_ascii=False)

@app.route("/")
@app.route("/maths-formulas")
def home():
    return render_template("maths_formulas.html", formula_data=load_formula_data())

@app.route("/maths-pdf")
def maths_pdf():
    filename = "AKTU_BTech_Maths_Formula_Book.pdf"
    folder = os.path.join(app.static_folder, "pdfs")
    if os.path.exists(os.path.join(folder, filename)):
        return send_from_directory(folder, filename, as_attachment=True)
    return "PDF not found. Put AKTU_BTech_Maths_Formula_Book.pdf in static/pdfs/.", 404

if __name__ == "__main__":
    app.run(debug=True)
