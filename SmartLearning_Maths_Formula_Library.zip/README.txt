# SmartLearning AI — AKTU Maths Formula Library

## Files
- `app.py` — standalone Flask demo app
- `templates/maths_formulas.html` — page markup
- `static/css/maths.css` — styling
- `static/js/maths.js` — search, filtering, copy buttons
- `static/pdfs/` — optional place for your existing PDF

## Run standalone
1. Install Python and Flask: `pip install flask`
2. Open a terminal in this folder.
3. Run: `python app.py`
4. Open `http://127.0.0.1:5000`

## Add to an existing SmartLearning AI Flask project
Do not replace your current `app.py`.
1. Copy `templates/maths_formulas.html` into your existing `templates` folder.
2. Copy `static/css/maths.css` into your existing `static/css` folder (create `css` if needed).
3. Copy `static/js/maths.js` into your existing `static/js` folder (create `js` if needed).
4. Copy `formula_data.json` into the same folder as your existing `app.py`.
5. Add a route to your existing `app.py`:

```python
import json
import os
from flask import render_template

@app.route("/maths-formulas")
def maths_formulas():
    data_path = os.path.join(app.root_path, "formula_data.json")
    with open(data_path, encoding="utf-8") as f:
        formula_data = json.load(f)
    return render_template("maths_formulas.html", formula_data=json.dumps(formula_data, ensure_ascii=False))
```

6. In the template, keep `window.MATHS_FORMULA_DATA = {{ formula_data|safe }};`.
7. Add a navigation link: `<a href="/maths-formulas">Maths Formula Library</a>`

## PDF option
Place `AKTU_BTech_Maths_Formula_Book.pdf` in `static/pdfs/`.
For an existing project, add this route if you want the download button to work:
```python
from flask import send_from_directory
@app.route("/maths-pdf")
def maths_pdf():
    return send_from_directory(os.path.join(app.static_folder, "pdfs"),
                               "AKTU_BTech_Maths_Formula_Book.pdf",
                               as_attachment=True)
```

## Syllabus accuracy
This is a broad common formula collection, not a verified exhaustive list for every AKTU batch/branch. Maths-III and Maths-IV subjects can vary. Match against your exact syllabus/subject codes before describing it as complete.
